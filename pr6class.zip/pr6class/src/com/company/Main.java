package com.company;

import java.io.*;
import java.util.Scanner;

class Main {

    public static void main(String args[]) throws Exception
    {
        Test test = new Test();
        test.test();
    }
}